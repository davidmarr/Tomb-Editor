-- Title script file

LevelFuncs.OnLoad = function() end
LevelFuncs.OnSave = function() end
LevelFuncs.OnEnd = function() end
LevelFuncs.OnStart = function() end
LevelFuncs.OnControlPhase = function(dt) end
